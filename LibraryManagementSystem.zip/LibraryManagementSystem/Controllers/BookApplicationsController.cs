﻿using System;
using System.Linq;
using System.Threading.Tasks;
using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.ViewModels.BookApplications;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Controllers
{
    public class BookApplicationsController : Controller
    {
        private readonly LibraryContext _context;

        public BookApplicationsController(LibraryContext context)
        {
            _context = context;
        }

        // ============================
        // APPLY FORM (GET)
        // ============================
        [Authorize(Roles = "Student")]
        [HttpGet]
        public async Task<IActionResult> Apply(int bookId)
        {
            var email = User.Identity?.Name;
            if (string.IsNullOrWhiteSpace(email)) return Unauthorized();

            // student "Normal ID"
            var namePart = email.Split('@')[0];
            var studentId = $"STU-{namePart.ToUpper()}";

            var book = await _context.Books.AsNoTracking().FirstOrDefaultAsync(b => b.Id == bookId);
            if (book == null) return NotFound();

            // default dates
            var issueDate = DateTime.Today;
            var returnDate = DateTime.Today.AddDays(14);

            var vm = new ApplyBookApplicationVM
            {
                BookId = book.Id,
                Title = book.Title,
                Author = book.Author,
                Category = book.Category,
                StudentId = studentId,
                IssueDate = issueDate,
                ReturnDate = returnDate
            };

            return View(vm);
        }

        // ============================
        // APPLY FORM (POST) -> SAVE TO BookApplications table
        // ============================
        [Authorize(Roles = "Student")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Apply(ApplyBookApplicationVM vm)
        {
            var email = User.Identity?.Name;
            if (string.IsNullOrWhiteSpace(email)) return Unauthorized();

            var namePart = email.Split('@')[0];
            var studentId = $"STU-{namePart.ToUpper()}";

            // Security: ensure studentId cannot be faked from form
            vm.StudentId = studentId;

            if (vm.ReturnDate < vm.IssueDate)
            {
                ModelState.AddModelError("", "Return Date cannot be before Issue Date.");
            }

            var bookExists = await _context.Books.AnyAsync(b => b.Id == vm.BookId);
            if (!bookExists)
            {
                ModelState.AddModelError("", "Book not found.");
            }

            if (!ModelState.IsValid)
            {
                // Re-fill book info for redisplay
                var book = await _context.Books.AsNoTracking().FirstOrDefaultAsync(b => b.Id == vm.BookId);
                if (book != null)
                {
                    vm.Title = book.Title;
                    vm.Author = book.Author;
                    vm.Category = book.Category;
                }
                return View(vm);
            }

            // Prevent duplicate application by same student for same book
            var alreadyApplied = await _context.BookApplications.AnyAsync(a =>
                a.BookId == vm.BookId && a.StudentId == studentId);

            if (alreadyApplied)
            {
                TempData["Error"] = "You already applied for this book.";
                return RedirectToAction("History");
            }

            var app = new BookApplication
            {
                BookId = vm.BookId,
                StudentId = studentId,
                IssueDate = vm.IssueDate,
                ReturnDate = vm.ReturnDate,
                CreatedAt = DateTime.UtcNow
            };

            _context.BookApplications.Add(app);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Book Application submitted successfully.";
            return RedirectToAction("History");
        }

        // ============================
        // HISTORY (visible to Everyone: Student/Librarian/Admin)
        // ============================
        [Authorize(Roles = "Student,Librarian,Admin")]
        [HttpGet]
        public async Task<IActionResult> History()
        {
            var list = await _context.BookApplications
                .AsNoTracking()
                .Include(a => a.Book)
                .OrderByDescending(a => a.CreatedAt)
                .ToListAsync();

            return View(list);
        }

        // ============================
        // EDIT (only dates) - Student who applied
        // ============================
        [Authorize(Roles = "Student")]
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var email = User.Identity?.Name;
            if (string.IsNullOrWhiteSpace(email)) return Unauthorized();

            var studentId = $"STU-{email.Split('@')[0].ToUpper()}";

            var app = await _context.BookApplications
                .Include(a => a.Book)
                .FirstOrDefaultAsync(a => a.Id == id);

            if (app == null) return NotFound();
            if (app.StudentId != studentId) return Forbid();

            var vm = new ApplyBookApplicationVM
            {
                BookId = app.BookId,
                Title = app.Book?.Title ?? "",
                Author = app.Book?.Author ?? "",
                Category = app.Book?.Category ?? "",
                StudentId = app.StudentId,
                IssueDate = app.IssueDate,
                ReturnDate = app.ReturnDate
            };

            ViewBag.ApplicationId = app.Id;
            return View(vm);
        }

        [Authorize(Roles = "Student")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, ApplyBookApplicationVM vm)
        {
            var email = User.Identity?.Name;
            if (string.IsNullOrWhiteSpace(email)) return Unauthorized();

            var studentId = $"STU-{email.Split('@')[0].ToUpper()}";

            var app = await _context.BookApplications.FirstOrDefaultAsync(a => a.Id == id);
            if (app == null) return NotFound();
            if (app.StudentId != studentId) return Forbid();

            if (vm.ReturnDate < vm.IssueDate)
            {
                ModelState.AddModelError("", "Return Date cannot be before Issue Date.");
            }

            if (!ModelState.IsValid)
            {
                ViewBag.ApplicationId = id;
                return View(vm);
            }

            // Only allow editing dates
            app.IssueDate = vm.IssueDate;
            app.ReturnDate = vm.ReturnDate;

            await _context.SaveChangesAsync();

            TempData["Success"] = "Application dates updated.";
            return RedirectToAction("History");
        }

        // ============================
        // DELETE (Admin only)
        // ============================
        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var app = await _context.BookApplications.FirstOrDefaultAsync(a => a.Id == id);
            if (app == null) return NotFound();

            _context.BookApplications.Remove(app);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Application deleted.";
            return RedirectToAction("History");
        }
    }
}
