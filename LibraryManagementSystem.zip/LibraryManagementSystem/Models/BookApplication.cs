﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryManagementSystem.Models
{
    public class BookApplication
    {
        public int Id { get; set; }

        [Required]
        public int BookId { get; set; }

        // "Normal ID" (your student ID / identifier)
        [Required]
        [MaxLength(100)]
        public string StudentId { get; set; } = "";

        [Required]
        public DateTime IssueDate { get; set; }

        [Required]
        public DateTime ReturnDate { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation
        [ForeignKey(nameof(BookId))]
        public Book? Book { get; set; }
    }
}
